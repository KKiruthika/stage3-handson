package com.cognizant.ormlearn;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.Exception.CountryNotFoundException;

@SpringBootApplication
public class OrmLearnApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	private static CountryService countryService;

	public static void main(String[] args) {
		// SpringApplication.run(OrmLearnApplication.class, args);
		LOGGER.info("Inside main");
		
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		countryService = context.getBean(CountryService.class);

		testGetAllCountries();
		testFindByNameContaining();
		testFindByNameContainingOrderByAsc();
		testfindByNameStartingWith();
		testDeleteCountry();
		try
		{
		testAddCountry();
		testUpdateCountry();
		}
		catch(CountryNotFoundException e)
		{
			e.printStackTrace();
		}

	}

	private static void testGetAllCountries() {

		LOGGER.info("Start");

		List<Country> countries = countryService.getAllCountries();

		LOGGER.debug("countries={}", countries);

		LOGGER.info("End");

	}
	private static void testAddCountry() throws CountryNotFoundException {

		LOGGER.info("Start");
		Country demoCountry = new Country();
		demoCountry.setCode("IN");
		demoCountry.setName("INDIA");
		countryService.addCountry(demoCountry);
		Country country = countryService.findCountryBycode("ZZ");
		System.out.println("Added Successfully");
		LOGGER.debug("Country:{}", country);
		
		LOGGER.info("End");

	}
	private static void testUpdateCountry() throws CountryNotFoundException {

		LOGGER.info("Start");
		countryService.updateCountry("IN", "IND");
		Country country = countryService.findCountryBycode("IN");
		LOGGER.debug("Country:{}", country);
		LOGGER.info("End");

	}
	private static void testDeleteCountry() {

		LOGGER.info("Start");
		countryService.deleteCountry("AS");
		LOGGER.info("End");

	}
	private static void testFindByNameContaining() {
		
		LOGGER.info("Start");
		List<Country>li=countryService.findByNameContaining("ou");
		for (Country c : li) {
			System.out.println(c.getCode() + " " + c.getName());
		}
		
	}
	private static void testFindByNameContainingOrderByAsc() {
		List<Country> li = countryService.findByNameContainingOrderByAsc("as");
		for (Country c : li) {
			System.out.println(c.getCode() + " " + c.getName());
		}
	}
	private static void testfindByNameStartingWith() {
		List<Country> li = countryService.findByNameStartingWith("a");
		for (Country c : li) {
			System.out.println(c.getCode() + " " + c.getName());
		}
	}

}