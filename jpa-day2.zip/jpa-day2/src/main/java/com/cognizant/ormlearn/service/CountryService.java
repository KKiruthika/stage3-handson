package com.cognizant.ormlearn.service;

import java.util.List;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryRepository;
import com.cognizant.ormlearn.service.Exception.CountryNotFoundException;

@Service
public class CountryService {

	@Autowired
	private CountryRepository countryRepository;
	
	@Transactional
	public List<Country> getAllCountries() {
		return countryRepository.findAll();
	}
	@Transactional
	public void addCountry(Country country) {
		countryRepository.save(country);
	}
	@Transactional
	public void updateCountry(String countryCode,String countryName)throws CountryNotFoundException {
		Optional<Country> res=countryRepository.findById(countryCode);
		if(!res.isPresent())
		{
			throw new CountryNotFoundException("Country not found!");
		}
		Country con=res.get();
		con.setName(countryName);
		countryRepository.save(con);
		
		}
	@Transactional
	public Country findCountryBycode(String countryCode)throws CountryNotFoundException {
		
		Optional<Country> res=countryRepository.findById(countryCode);
		if(!res.isPresent())
		{
			throw new CountryNotFoundException("Country not found!");
		}
		Country con=res.get();
		return con;
	}
	@Transactional
	public void deleteCountry(String countryCode){
		countryRepository.deleteById(countryCode);
	}
	@Transactional 
	public List<Country> findByNameContaining(String str){
		List<Country> list=countryRepository.findByNameContaining(str);
		return list;
	}
	
	@Transactional 
	public List<Country> findByNameContainingOrderByAsc(String str){
		List<Country> list=countryRepository.findByNameContainingOrderByNameAsc(str);
		return list;
	}
	
	@Transactional
	public List<Country> findByNameStartingWith(String str){
		return countryRepository.findByNameStartingWith(str);
	}
}