package com.cognizant.ormlearn.service.Exception;

public class CountryNotFoundException extends Exception{
	
	public CountryNotFoundException(String message) {
		super(message);
	}

}